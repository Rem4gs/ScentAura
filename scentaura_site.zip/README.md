# ScentAura — Starter Website
Files:
- index.html (Home with About/Mission/Vision)
- products.html (Products split by Men / Women)
- services.html
- contact.html
- styles.css

How to use:
1. Unzip and open index.html in your browser to preview locally.
2. To publish: push the files to a GitHub repo and enable GitHub Pages (branch: main, folder: root).

Need me to add a simple cart or convert to Tailwind? Reply here and I'll update the files.
